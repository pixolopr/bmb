<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 
 class Tax_model extends PIXOLO_Model 
 { 
	 public $_table = 'tax';  
 
 	 //Write functions here 
 } 
 
 ?>