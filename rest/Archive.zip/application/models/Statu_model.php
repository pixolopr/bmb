<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 
 class Statu_model extends PIXOLO_Model 
 { 

 
 	 //Write functions here 
 } 
 
 ?>